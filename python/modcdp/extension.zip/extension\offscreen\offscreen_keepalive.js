// extension/src/pages/offscreen_keepalive.ts
var MODCDP_OFFSCREEN_KEEPALIVE_PORT = "ModCDPOffscreenKeepAlive";
var MODCDP_OFFSCREEN_KEEPALIVE_INTERVAL_MS = 1e3;
var MODCDP_OFFSCREEN_RECONNECT_DELAY_MS = 250;
var port = null;
function sendKeepAlive() {
  port?.postMessage({ type: "ModCDPOffscreenKeepAlive", at: Date.now() });
}
function connectKeepAlivePort() {
  port = chrome.runtime.connect({ name: MODCDP_OFFSCREEN_KEEPALIVE_PORT });
  port.onDisconnect.addListener(() => {
    port = null;
    setTimeout(connectKeepAlivePort, MODCDP_OFFSCREEN_RECONNECT_DELAY_MS);
  });
  sendKeepAlive();
}
connectKeepAlivePort();
setInterval(sendKeepAlive, MODCDP_OFFSCREEN_KEEPALIVE_INTERVAL_MS);
//# sourceMappingURL=offscreen_keepalive.js.map
